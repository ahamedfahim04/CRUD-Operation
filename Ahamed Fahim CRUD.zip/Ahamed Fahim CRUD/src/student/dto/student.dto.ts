export interface StudentDTO {
    
    readonly name: string;
    readonly age: number;
    readonly gender: string;
    readonly native: string;
}