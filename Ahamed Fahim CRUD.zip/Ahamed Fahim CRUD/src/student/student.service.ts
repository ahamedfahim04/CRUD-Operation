import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Student } from './inerface/student.interface';
import { StudentDTO } from './dto/student.dto';
@Injectable()
export class StudentService {

    constructor(@InjectModel('Student') private StudentModel: Model<Student>) {}

    async getStudents(): Promise<Student[]> {
        return await this.StudentModel.find().exec();
    }

    async getOneStudent(id: string): Promise<Student | null> {
        return await this.StudentModel.findById(id).exec();
    }
    
    async updateOneStudent(id: string, data: StudentDTO): Promise<Student | null> {
        return await this.StudentModel.findByIdAndUpdate(id, data, {new: true}).exec();
    }

    async deleteOneStudent(id: string): Promise<Student | null> {
        return await this.StudentModel.findByIdAndDelete(id).exec();
    }

   async createStudent(data: StudentDTO): Promise<Student> {
        const student = new this.StudentModel(data);
        return await student.save();

    }
}
